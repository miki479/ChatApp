const express = require("express");
const app = express();
const port = 3000;

// Imposta EJS come motore di template
app.set("view engine", "ejs");

// Middleware per servire file statici (CSS, JS, etc.)
app.use(express.static("public"));

// Funzione per generare il lotto
function getLotto() {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now - start;
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    const year = now.getFullYear().toString().slice(-2);
    return `L${year}${String(dayOfYear).padStart(3, "0")}`;
}

// Route principale
app.get("/", (req, res) => {
    const lotto = getLotto();
    res.render("index", { lotto });
});

// Avvia il server
app.listen(port, () => {
    console.log(`App listening at http://localhost:${port}`);
});
